# Birch Boy

A touch-friendly HTML5 game starring Eddy. Endless progressively harder levels, timing combos, wildlife encounters and horse jumps. Tap CHOP or press Space. Catch green for double birch. Wait when wildlife arrives: sparing animals earns 50 points. Hitting one triggers a cartoon death, costs a campaign heart and deducts 100 points. Three hearts; running out of time or hearts ends the run. Best score is saved on your device.

## Audio

Sound is on by default. The splash screen attempts to play Birch Boy and Eddy.mp3 automatically. If browser autoplay policy blocks it, tap the splash screen or Play theme to start audio. Starting the game stops the theme. chop.mp3 plays each swing when sound is on, and neigh.mp3 plays once at horse takeoff. Eddy’s head rocks with each swing. Switching tabs pauses gameplay and audio.

## Run locally

Open dist/index.html or run `python -m http.server 8765 --directory dist` from this folder. No build or dependencies required.

## GitHub Pages

1. Upload this folder's contents, including .github, to the main branch of your repository. Exclude the local .git and .openai directories.
2. In Settings > Pages, select GitHub Actions as the source.
3. Push to main or run Deploy Birch Boy to GitHub Pages from Actions.

The included workflow deploys dist/. All asset paths are relative, supporting repository subpaths. The GitHub-ready ZIP excludes previous Sites hosting metadata and local Git history. No credentials or backend required.

Assets supplied by the creator: eddy_head.png, Birch Boy and Eddy.mp3, chop.mp3 and neigh.mp3. Other artwork uses Canvas. Google Fonts is optional, with local fallbacks.

## Endless difficulty

Each level cuts three seconds from the timer, increases the birch target (up to ten bundles), speeds the rhythm, narrows the green zone, and brings wildlife more frequently with shorter warnings. Squirrels, birds, foxes, rabbits, owls and badgers join the woods. Three hearts carry through the entire run. Late levels become deliberately impossible: at a one-second limit even perfect tapping cannot collect enough birch. The challenge is how far you can get.

Run `node verify-game.cjs` for the game checks.
